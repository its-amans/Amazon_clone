# Amazon_clone
It is an amzon front page clone
